package com.mingze.doll;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import java.util.Vector;

public abstract class Sprite {
    //translate 1, rotate 2, scale 3, nothing 0
    private int mode;
    private Sprite parent;
    private Vector<Sprite> children;
    private float inter_x;
    private float inter_y;
    private float center_x;
    private float center_y;
    private Matrix matrix;
    private float degree;



    public Sprite() {
        mode = 0;
        parent = null;
        children = new Vector<Sprite>();
        inter_x=-1;
        inter_y=-1;
        center_x=-1;
        center_y=-1;
        matrix = new Matrix();
        degree = 0;
    }

    public void clearChildren(){
        children = new Vector<Sprite>();
    }




    public float getInter_x() {
        return inter_x;
    }

    public void setInter(float inter_x, float inter_y) {
        this.inter_x = inter_x;
        this.inter_y = inter_y;
    }

    public float getInter_y() {
        return inter_y;
    }



    public void changeCenter(float x, float y){
        center_x=x;
        center_y=y;
    }

    public void addChildren(Sprite s) {
        children.add(s);
        s.setParent(this);
    }

    public void setParent(Sprite s){
        parent = s;
    }


    public void translate(float diffx, float diffy) {
        matrix.postTranslate(diffx, diffy);
    }

    public void rotate(float degrees, float x, float y, int limit){
        Matrix tmp = getFullTransformation();
        float[] point = {inter_x, inter_y};
        float epsilon = 1;
        if((degrees >0) && (Math.abs(degrees)<2)){
            degrees = 4;
        }else if((degrees <0) && (Math.abs(degrees)<2)){
            degrees = -4;
        }
        float newdegree = getDegree()+degrees;
        if(((-limit)<=newdegree)&&(limit>=newdegree)){
            matrix.postRotate(degrees*epsilon, point[0], point[1]);
            setDegree(newdegree);
        }


    }

    public void scale(float scaleFactor){
        translate(-inter_x, -inter_y);
        float x = scaleFactor;
        if(x > 1.5){
            x-=0.5;
        }
        matrix.postScale(x, scaleFactor);
        translate(inter_x, inter_y);
    }



    public abstract int pointIsInside(float x, float y);

    protected abstract void drawSprite(Canvas c, Paint p);


    public Matrix getFullTransformation() {
        Matrix fulltransform = new Matrix();
        Sprite curr = this;
        while (true) {
            if(curr == null){
                break;
            }
            Matrix m = new Matrix(curr.matrix);
            fulltransform.postConcat(m);
            curr = curr.parent;
        }
        return fulltransform;
    }


    public Sprite getSpriteHit(MotionEvent event) {
        int length = children.size();
        for (int i=0; i<length; i++) {
            Sprite sp = children.get(i);
            Sprite s = sp.getSpriteHit(event);
            if (s != null) {
                return s;
            }
        }
        if (this.pointIsInside(event.getX(), event.getY())==1) {
            return this;
        }
        return null;
    }




    public void draw(Canvas canvas, Paint paint) {
        //refer to java example professor provided in class
        Matrix m = canvas.getMatrix();
        Matrix curr = canvas.getMatrix();
        curr.postConcat(this.getFullTransformation());
        canvas.setMatrix(curr);
        //refer to java example professor provided in class
        this.drawSprite(canvas, paint);
        canvas.setMatrix(m);

        for (Sprite sprite : children) {
            sprite.draw(canvas, paint);
        }
    }

    public float getDegree() {
        return degree;
    }

    public void setDegree(float degree) {
        this.degree = degree;
    }

    public float getDegree(float initDegree, float x, float y){
        float angle = (float) Math.atan2((double) y - inter_y, x - inter_x);
        float degree = (float) Math.toDegrees((double) (angle - initDegree));
        return degree;
    }
}
