package com.mingze.doll;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;

public class Rect extends Sprite{
    float left;
    float top;
    float width;
    float height;
    float rfactor;

    Rect(float w, float h, float r) {
        left = 0;
        top = 0;
        width = w;
        height = h;
        rfactor = r;

    }

    public int pointIsInside(float x, float y){
        //refer to java example professor provided in class
        float[] point = new float[2];
        point[0] = x;
        point[1] = y;
        Matrix matrix = this.getFullTransformation();
        Matrix inverse = new Matrix();
        matrix.invert(inverse);

        inverse.mapPoints(point);
        RectF temp = new RectF(0, 0, width, height);
        //checks whether the point is inside
        if(temp.contains(point[0], point[1])){
            return 1;
        }
        return 0;
    }

    protected void drawSprite(Canvas c, Paint p){
        c.drawRoundRect(left, top, left + width, top + height, rfactor, rfactor, p);
    }

}

