package com.mingze.doll;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsoluteLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Board board;
    Model model;
    int resetNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        resetNum = 0;
        setContentView(R.layout.activity_main);
        ImageView layout = (ImageView) findViewById(R.id.paintboard);
        model = new Model();
        board = new Board(this, layout, model);

        View about = (View) findViewById(R.id.about);
        about.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                pop(v);
            }
        });

        View reset = (View) findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //do nothing, force the board to refresh itself
                board.setCanvas(board.getStatus());
                board.draw();
            }
        });


        board.setCanvas(board.getStatus());



        View figure2 = (View) findViewById(R.id.figure2);
        figure2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(board.getStatus()==1){
                    board.setStatus(2);
                    board.setCanvas(2);
                }else{
                    board.setStatus(1);
                    board.setCanvas(1);
                }
                board.draw();
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        int height = findViewById(R.id.paintboard).getHeight();
        int width = findViewById(R.id.paintboard).getWidth();
        board.setConfig(height, width);
    }

    public void pop(View v){
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popup = inflater.inflate(R.layout.popup, null);
        //focusable -> outside will dismiss popup window
        boolean focus = true;
        final PopupWindow window = new PopupWindow(popup, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, focus);
        window.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        LinearLayout pop = (LinearLayout) popup.findViewById(R.id.pop);
        pop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                window.dismiss();
            }
        });
    }
}
