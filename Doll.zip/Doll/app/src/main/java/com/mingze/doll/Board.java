package com.mingze.doll;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.MainThread;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Board extends View implements Observer {
    private ImageView layout;
    private Model model;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private int w;
    private int h;
    private Matrix matrix;
    private Rect head;
    private Rect torso;
    private Rect ula;
    private Rect lla;
    private Rect lhand;

    private Rect ura;
    private Rect lra;
    private Rect rhand;
    private PointF prev_pos;

    private Rect ull;
    private Rect lll;
    private Rect lfeet;

    private Rect url;
    private Rect lrl;
    private Rect rfeet;

    private Rect head2;
    private Rect ear1;
    private Rect ear2;

    private Rect leg1;
    private Rect leg2;
    private Rect leg3;
    private Rect leg4;

    private Rect tail;


    private float scaleFactor;
    private int scaling;
    private Rect scaleObject;
    private ScaleGestureDetector SGD;
    private int status;


    public Board(Context context, ImageView lo, Model m)
    {
        super(context);
        layout = lo;
        model = m;
        matrix = new Matrix();
        SGD = new ScaleGestureDetector(context, new ScaleListener());
        status = 1;
    }

    public void draw(){
        canvas.drawColor(Color.WHITE);
        torso.draw(canvas, paint);
        layout.setImageBitmap(bitmap);
        invalidate();
    }

    public void setConfig(int height, int width){
        w = width;
        h = height;
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);

        draw();
    }


    public void setAnimal(){
        //once torso is reinit the old image is gone.
        torso = new Rect(500, 190, 20);
        torso.translate(600, 600);

        //head
        head2 = new Rect(150, 200, 70);
        head2.translate(-150, -95);
        torso.addChildren(head2);
        head2.setInter(0, 0);

        //ear
        ear1 = new Rect(50, 100, 25);
        ear1.translate(10, -100);
        head2.addChildren(ear1);
        ear1.setInter(10, 0);

        //ear
        ear2 = new Rect(50, 100, 25);
        ear2.translate(90, -100);
        head2.addChildren(ear2);
        ear2.setInter(90, 0);

        //leg1
        leg1 = new Rect(50, 200, 25);
        leg1.translate(0, 190);
        torso.addChildren(leg1);
        leg1.setInter(0, 190);

        //leg2
        leg2 = new Rect(50, 200, 25);
        leg2.translate(70, 190);
        torso.addChildren(leg2);
        leg2.setInter(70, 190);

        //leg3
        leg3 = new Rect(50, 200, 25);
        leg3.translate(450, 190);
        torso.addChildren(leg3);
        leg3.setInter(450, 190);

        //leg4
        leg4 = new Rect(50, 200, 25);
        leg4.translate(380, 190);
        torso.addChildren(leg4);
        leg4.setInter(380, 190);

        //tail
        tail = new Rect(90, 110, 80);
        tail.translate(480, -130);
        torso.addChildren(tail);
        tail.setInter(480, -10);


        //canvas listener
        layout.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float finger_x;
                float finger_y;
                int f = 0;
                SGD.onTouchEvent(event);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        prev_pos = new PointF(event.getX(), event.getY());
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        finger_x = event.getX();
                        finger_y = event.getY();

                        float diffx = finger_x - prev_pos.x;
                        float diffy = finger_y - prev_pos.y;

                        if (torso.pointIsInside(event.getX(), event.getY())==1) {
                            torso.translate(diffx, diffy);
                        }else if(head2.pointIsInside(event.getX(), event.getY())==1){
                            rotate(head2, finger_x, finger_y, 15, 1);
                        }else if(ear1.pointIsInside(event.getX(), event.getY())==1){
                            rotate(ear1, finger_x, finger_y, 35, 1);
                        }else if(ear2.pointIsInside(event.getX(), event.getY())==1){
                            rotate(ear2, finger_x, finger_y, 35, 1);
                        } else if(leg1.pointIsInside(event.getX(), event.getY())==1){
                            rotate(leg1, finger_x, finger_y, 90, 2);
                        } else if(leg2.pointIsInside(event.getX(), event.getY())==1){
                            rotate(leg2, finger_x, finger_y, 90, 2);
                        } else if(leg3.pointIsInside(event.getX(), event.getY())==1){
                            rotate(leg3, finger_x, finger_y, 90, 2);
                        } else if(leg4.pointIsInside(event.getX(), event.getY())==1){
                            rotate(leg4, finger_x, finger_y, 90, 2);
                        } else if(tail.pointIsInside(event.getX(), event.getY())==1){
                            rotate(tail, finger_x, finger_y, 30, 1);
                        }




                        prev_pos = new PointF(finger_x, finger_y);
                        draw();

                        break;
                    case MotionEvent.ACTION_UP:
                        prev_pos = new PointF(event.getX(), event.getY());
                        return true;
                }
                return true;
            }
        });

    }

    public int getStatus(){
        return status;
    }

    public void setStatus(int s){
        status = s;
    }

    //status 1 = normal, status 2 = figure2
    public void setCanvas(int s) {
        status=s;
        if(s == 2){
            setAnimal();
            draw();
            return;
        }
        //torso
        torso = new Rect(150, 300, 20);
        torso.translate(400, 200);
        //head
        head = new Rect(80, 150, 40);
        head.translate(35, -150);
        torso.addChildren(head);
        head.setInter(75, 0);
        //upper left arm
        ula = new Rect(40, 190, 20);
        ula.translate(-55, 10);
        torso.addChildren(ula);
        ula.setInter(-55, 10);
        //lower left
        lla = new Rect(40, 150, 20);
        lla.translate(0, 200);
        ula.addChildren(lla);
        lla.setInter(0, 200);
        //left hand
        lhand = new Rect(60, 80, 10);
        lhand.translate(-20, 150);
        lla.addChildren(lhand);
        lhand.setInter(10, 150);
        //upper right
        ura = new Rect(40, 190, 20);
        ura.translate(165, 10);
        torso.addChildren(ura);
        ura.setInter(165, 10);
        //lower left
        lra = new Rect(40, 150, 20);
        lra.translate(0, 200);
        ura.addChildren(lra);
        lra.setInter(0, 200);
        //right hand
        rhand = new Rect(60, 80, 10);
        rhand.translate(-10, 150);
        lra.addChildren(rhand);
        rhand.setInter(20, 150);
        //upper left leg
        ull = new Rect(40, 190, 20);
        ull.translate(0, 310);
        torso.addChildren(ull);
        ull.setInter(0, 310);
        //lower left leg
        lll = new Rect(40, 150, 20);
        lll.translate(0, 200);
        ull.addChildren(lll);
        lll.setInter(0, 200);
        //left feet
        lfeet = new Rect(60, 80, 10);
        lfeet.translate(-20, 150);
        lll.addChildren(lfeet);
        lfeet.setInter(10, 150);
        //upper right leg
        url = new Rect(40, 190, 20);
        url.translate(110, 310);
        torso.addChildren(url);

        url.setInter(110, 310);
        //lower right leg
        lrl = new Rect(40, 150, 20);
        lrl.translate(0, 200);
        url.addChildren(lrl);
        lrl.setInter(0, 200);
        //right feet
        rfeet = new Rect(60, 80, 10);
        rfeet.translate(-10, 150);
        lrl.addChildren(rfeet);
        rfeet.setInter(20, 150);

        //canvas listener
        layout.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float finger_x;
                float finger_y;
                int f = 0;
                SGD.onTouchEvent(event);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        prev_pos = new PointF(event.getX(), event.getY());
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        finger_x = event.getX();
                        finger_y = event.getY();

                        float diffx = finger_x - prev_pos.x;
                        float diffy = finger_y - prev_pos.y;

                        if (torso.pointIsInside(event.getX(), event.getY())==1) {
                            torso.translate(diffx, diffy);
                        }else if(head.pointIsInside(event.getX(), event.getY())==1){
                            rotate(head, finger_x, finger_y, 50, 1);
                        }else if(ula.pointIsInside(event.getX(), event.getY())==1){
                            rotate(ula, finger_x, finger_y, 90, 2);
                        }else if(lla.pointIsInside(event.getX(), event.getY())==1){
                            rotate(lla, finger_x, finger_y, 90, 2);
                        }else if(lhand.pointIsInside(event.getX(), event.getY())==1){
                            rotate(lhand, finger_x, finger_y, 35, 2);
                        }else if(ura.pointIsInside(event.getX(), event.getY())==1){
                            rotate(ura, finger_x, finger_y, 90, 2);
                        }else if(lra.pointIsInside(event.getX(), event.getY())==1){
                            rotate(lra, finger_x, finger_y, 90, 2);
                        }else if(rhand.pointIsInside(event.getX(), event.getY())==1){
                            rotate(rhand, finger_x, finger_y, 35, 2);
                        }else if(ull.pointIsInside(event.getX(), event.getY())==1){
                            if(scaling==1){
                                ull.scale(scaleFactor);
                            }
                            rotate(ull, finger_x, finger_y, 90, 2);
                        }else if(lll.pointIsInside(event.getX(), event.getY())==1){
                            if(scaling==1){
                                lll.scale(scaleFactor);
                            }
                            rotate(lll, finger_x, finger_y, 90, 2);
                        }else if(lfeet.pointIsInside(event.getX(), event.getY())==1){
                            rotate(lfeet, finger_x, finger_y, 35, 2);
                        }else if(url.pointIsInside(event.getX(), event.getY())==1){
                            if(scaling==1){
                                url.scale(scaleFactor);
                            }
                            rotate(url, finger_x, finger_y, 90, 2);
                        }else if(lrl.pointIsInside(event.getX(), event.getY())==1){
                            if(scaling==1){
                                lrl.scale(scaleFactor);
                            }
                            rotate(lrl, finger_x, finger_y, 90, 2);
                        }else if(rfeet.pointIsInside(event.getX(), event.getY())==1){
                            rotate(rfeet, finger_x, finger_y, 35, 2);
                        }

                        prev_pos = new PointF(finger_x, finger_y);
                        draw();

                        break;
                    case MotionEvent.ACTION_UP:
                        prev_pos = new PointF(event.getX(), event.getY());
                        return true;
                }
                return true;
            }
        });
    }


    public void rotate(Rect shape, float finger_x, float finger_y, int limit, int kind){
        Matrix m = shape.getFullTransformation();
        Matrix inverse = new Matrix();
        matrix.invert(inverse);
        float[] newpoint = new float[2];
        newpoint[0] = finger_x;
        newpoint[1] = finger_y;
        float[] oldpoint = new float[2];
        oldpoint[0] = prev_pos.x;
        oldpoint[1] = prev_pos.y;
        inverse.mapPoints(newpoint);
        inverse.mapPoints(oldpoint);

        float formula1 = (float) Math.sqrt(oldpoint[0] * oldpoint[0] + oldpoint[1] * oldpoint[1]);
        float formula2 = (float) Math.sqrt(newpoint[0] * newpoint[0]+ newpoint[1] * newpoint[1]);
        float cos = ((oldpoint[0] * newpoint[0]) + (oldpoint[1] * newpoint[1]))/(formula1 * formula2);
        if(cos >= 1) cos = 1;
        if(cos <= -1) cos =-1;

        float degree = (float) Math.toDegrees(Math.acos(cos));

        if(kind == 1){
            if (oldpoint[0]< newpoint[0]) {//clockwise
                shape.rotate(degree, newpoint[0], newpoint[1], limit);
            }else{//counter clockwise
                shape.rotate((-1) * degree, newpoint[0], newpoint[1], limit);
            }
        }else if(kind == 2){
            if (oldpoint[0]> newpoint[0]) {//clockwise
                shape.rotate(degree, newpoint[0], newpoint[1], limit);
            }else{//counter clockwise
                shape.rotate((-1) * degree, newpoint[0], newpoint[1], limit);
            }
        }

    }


    public class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener{
        @Override
        public boolean onScale(ScaleGestureDetector detector){
            scaleFactor = detector.getScaleFactor();
            scaleFactor = Math.max(0.3f, Math.min(scaleFactor, 1.5f));

            return true;
        }
        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector) {
            scaleFactor = 1;
            scaling = 1;
            return true;
        }
        @Override
        public void onScaleEnd(ScaleGestureDetector detector) {
            scaling = 0;
            scaleFactor = 1;
        }
    }


    @Override
    public void update(Observable o, Object arg)
    {

    }

}
