package com.mingze.doll;


import java.util.ArrayList;

public class Model {
    private ArrayList<ArrayList<Float>> list;


    Model() {
        list = new ArrayList<ArrayList<Float>>();
    }

    public ArrayList<ArrayList<Float>> getList() {
        return list;
    }

    public void setList(ArrayList<ArrayList<Float>> list) {
        this.list = list;
    }

    public void addList(ArrayList<Float> member){
        list.add(member);
    }
}
