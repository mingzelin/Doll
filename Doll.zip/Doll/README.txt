made by Mingze Lin
id: 20655470
email: m59lin@edu.uwaterloo.ca



MAC
openjdk 12.0.2 2019-07-16
OpenJDK Runtime Environment AdoptOpenJDK (build 12.0.2+10)
OpenJDK 64-Bit Server VM AdoptOpenJDK (build 12.0.2+10, mixed mode, sharing)

///////////IMPORTANT
TESTED ON ANDROID MACHINE:
Google Pixel C borrowed from DC lib (Android Version 8.1.0)
///////////IMPORTANT

API:
My program supports machines that has api28, api29.



Note:
All translation, rotation and scaling functions are implemented.


Feature:
Multiple ragdolls. 
When click the FIGURE2 button it can switch to animal doll (dog).


Thank You